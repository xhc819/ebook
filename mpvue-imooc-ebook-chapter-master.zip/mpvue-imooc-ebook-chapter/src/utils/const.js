export const APP_ID = 'wx6ca257b141a31ade'
export const APP_SECRET = 'a32f84636cfcdba9688f928da3e2cbb4'

export const HOME_BOOK_MODE = {
  ROW: 'row',
  COL: 'col',
  CATEGORY: 'category'
}

export const CATEGORY = {
  computerscience: '计算机科学',
  socialsciences: '社会科学',
  economics: '经济学',
  education: '教育学',
  engineering: '工程学',
  environment: '环境学',
  geography: '地理学',
  history: '历史学',
  laws: '法学',
  lifesciences: '生命科学',
  literature: '文学',
  biomedicine: '生物医学',
  businessandmanagement: '工商管理',
  earthsciences: '地球科学',
  materialsscience: '材料科学',
  mathematics: '数学',
  medicineandpublichealth: '公共卫生',
  philosophy: '哲学',
  physics: '物理',
  politicalscienceandinternationalrelations: '国际关系',
  psychology: '心理学',
  statistics: '统计学'
}
