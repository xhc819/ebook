import Vue from 'vue'
import App from './shelf'

const app = new Vue(App)
app.$mount()
