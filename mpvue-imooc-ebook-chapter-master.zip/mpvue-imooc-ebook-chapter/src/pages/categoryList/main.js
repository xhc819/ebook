import Vue from 'vue'
import App from './categoryList'

const app = new Vue(App)
app.$mount()
