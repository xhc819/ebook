import Vue from 'vue'
import App from './read'

const app = new Vue(App)
app.$mount()
